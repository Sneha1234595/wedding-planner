<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="portfolio.php"> <i class="fas fa-angle-right"></i> portfolio</a>
         <a href="pricing.php"> <i class="fas fa-angle-right"></i> pricing</a>
         <a href="contact.php"> <i class="fas fa-angle-right"></i> contact</a>
         <a href="login.php"> <i class="fas fa-angle-right"></i> login</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> plan wedding</a>
         <a href="#"> <i class="fas fa-angle-right"></i> our services</a>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i>  +91 8471011273 </a>
         <a href="#"> <i class="fas fa-phone"></i>+91 9301707198 </a>
         <a href="#"> <i class="fas fa-envelope"></i> psinghkd718@gmail.com </a>
         <a href="#"> <i class="fas fa-envelope"></i> shubhanjalipatel4@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> varanasi-India-221002  </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="https://www.facebook.com/profile.php?id=100070851677024&mibextid=ZbWKwL"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="https://twitter.com/Priyauu03?t=AqA8iuqm5AnIo2CfbkAZgQ&s=09"> <i class="fab fa-twitter"></i> twitter </a>
         <a href="https://instagram.com/___shubhi_7071___?igshid=YmMyMTA2M2Y="> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
         <a href="https://github.com/01shubhi"> <i class="fab fa-github"></i> github </a>
      </div>

   </div>

   <p class="credit"> created by <span>priya & shubhanjali patel </span></p>

</section>